function pool:classes/lobby/terminate_helper

tag @a[distance=0.001..] remove swPool_wait
tag @a[distance=0.001..] remove swPool_wait_snooker

tag 000c2be1-0001-414d-0000-000000000000 remove swPool_multiplayer
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_singleplayer

execute unless entity 000c2be1-0001-414d-0000-000000000000 run tellraw @s[tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Please place a table first.","color":"red"}]
execute unless entity 000c2be1-0001-414d-0000-000000000000 run tellraw @s[tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"请先放置球桌。","color":"red"}]

scoreboard players set @a swPool_Score 0

tag 000c2be1-0001-414d-0000-000000000000 add swPool_start

tag @a[tag=swPool_wait_snooker,limit=1] add swPool_poolplay

execute unless score #bot_turn swMath_V matches 1 run tag @a[tag=swPool_poolplay,limit=1] add swPool_ballinhand
execute unless score #bot_turn swMath_V matches 1 as @a[tag=swPool_ballinhand] at @s run function app:get/pool/cueball_helper
scoreboard players set Opponent swPool_Score 0
scoreboard objectives setdisplay sidebar

scoreboard players set Stroke swPool_hidScore 0

tag 000c2be1-0001-414d-0000-000000000000 remove swPool_dialogue
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_sidebar
execute if data storage minecraft:swpool {displayscore:'dialogue'} run tag 000c2be1-0001-414d-0000-000000000000 add swPool_dialogue
execute if data storage minecraft:swpool {displayscore:'sidebar'} run scoreboard objectives setdisplay sidebar swPool_Score
execute if data storage minecraft:swpool {displayscore:'sidebar'} run tag 000c2be1-0001-414d-0000-000000000000 add swPool_sidebar

execute as @a[tag=swPool_poolplay,limit=1] at @s if entity @a[tag=swPool_poolplay,distance=0.01..] run tag 000c2be1-0001-414d-0000-000000000000 add swPool_multiplayer
execute as @a[tag=swPool_poolplay,limit=1] at @s unless entity @a[tag=swPool_poolplay,distance=0.01..] run tag 000c2be1-0001-414d-0000-000000000000 add swPool_singleplayer

execute as 000c2be1-0001-414d-0000-000000000000 at @s positioned ~ ~ ~ run function pool:classes/snooker/balls

tag @a remove swPool_wait
tag @a remove swPool_wait_9ball
tag @a remove swPool_wait_cn8ball
tag @a remove swPool_wait_uk8ball
tag @a remove swPool_wait_snooker

tag @a[tag=swPool_poolplay] add swPool_spec

scoreboard players set #breakshot swPool_v 0
scoreboard players set swPool_gameon swMath_V 1
