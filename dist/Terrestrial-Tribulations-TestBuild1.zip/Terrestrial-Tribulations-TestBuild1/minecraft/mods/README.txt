Mods are downloaded here automatically by TT ModSync when you press Launch.
