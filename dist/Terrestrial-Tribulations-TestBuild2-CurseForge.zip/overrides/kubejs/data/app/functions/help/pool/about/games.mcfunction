tellraw @s[tag=swPool_EN] [{"text":"➇ Games in this datapack:","color":"gold"}]

tellraw @s[tag=swPool_EN] [{"text":"➇ Snooker: ","color":"gold"},{"text":"Score points by potting red and colored balls alternately. Colored balls are respotted until all reds are cleared, then must be potted in order of increasing value. Fouls award points to the opponent. After a foul, if the incoming player is snookered, a Free Ball may be awarded, allowing another ball to be treated as the ball on. This is different from Ball in Hand in 8-ball or 9-ball, where the cue ball may be repositioned. The player with the highest score after all balls are potted wins. Rules may vary by region; this preset is a simplified version.","color":"white"}]

tellraw @s[tag=swPool_EN] [{"text":"➇     UK 8-Ball: ","color":"gold"},{"text":"Choose either red or yellow balls, clear your group, then pot the black ball to win. Fouls give the opponent two visits. Scratching also gives the opponent ball in hand in the kitchen. Rules may vary; this preset is one common implementation.","color":"white"}]

tellraw @s[tag=swPool_EN] [{"text":"➇     8-Ball: ","color":"gold"},{"text":"Choose solids (1–7) or stripes (9–15), clear your group, then pot the black (8) ball to win. Fouls give the opponent ball in hand anywhere (or in the kitchen if scratched on the break). Rules may vary; this preset is based on a Chinese 8-ball style.","color":"white"}]

tellraw @s[tag=swPool_EN] [{"text":"➇     9-Ball: ","color":"gold"},{"text":"Always strike the lowest-numbered ball first. Any ball can be potted, and the player continues shooting as long as the first contact is legal. The player who legally pots the 9 ball wins. Fouls give the opponent ball in hand anywhere. Rules may vary by region; this preset is one common implementation.","color":"white"}]

tellraw @s[tag=swPool_EN] [{"text":"➇ In single-player snooker, you play as one role and fouls add points to a simulated opponent. In single-player 8 ball games, you choose one role or alternate between two roles.","color":"white"},{"text":"\n　     Role switching and game rules can be configurable using 'Gamerule Settings' in lobby window.","color":"gold"}]

tellraw @s[tag=swPool_CN] [{"text":"➇　本数据包包含以下游戏玩法：","color":"gold"}]

tellraw @s[tag=swPool_CN] [{"text":"➇　　斯诺克：","color":"gold"},{"text":"通过交替击打红球和彩球得分。彩球在红球未打完前会被复位；红球打完后，需按分值从低到高依次击打彩球。犯规会给对手加分；犯规后若对手处于斯诺克状态，还可能获得“自由球”，即可以将其他球暂时视为当前目标球击打。斯诺克中的“自由球”与八球、九球中的“手中球”不同，后者是允许重新摆放母球。所有球打完后，得分高者获胜。规则因地区有所不同，数据包为简化玩法。","color":"white"}]

tellraw @s[tag=swPool_CN] [{"text":"➇　　英式八球：","color":"gold"},{"text":"选择红球或黄球，将本方球全部打进后再击打黑球获胜。犯规给予对手两次击球机会，若母球入袋则对手获得开球区内手中球。规则因地区有所不同，数据包为常见玩法之一。","color":"white"}]

tellraw @s[tag=swPool_CN] [{"text":"➇　　八球：","color":"gold"},{"text":"选择全色球（1–7）或花色球（9–15），将本方球全部打进后再击打黑球（8号）获胜。犯规给予对手全场手中球（开球犯规则在开球区内）。规则因地区有所不同，此模式基于中式八球风格。","color":"white"}]

tellraw @s[tag=swPool_CN] [{"text":"➇　　九球：","color":"gold"},{"text":"始终先击打当前最小编号的球，但可以打进任意球。只要首次击球合法且有进球即可继续击球。合法打进9号球即获胜。犯规给予对手全场手中球。规则因地区有所不同，数据包为常见玩法之一。","color":"white"}]

tellraw @s[tag=swPool_CN] [{"text":"➇　单人斯诺克模式中，你以单一身份进行游戏，犯规将为“模拟对手”加分。八球单人模式中，你将扮演单方或双方轮流击球。","color":"white"},{"text":"\n　　在游戏大厅选择 “游戏规则设置” 自定义游戏规则和切换角色的设置。","color":"gold"}]
