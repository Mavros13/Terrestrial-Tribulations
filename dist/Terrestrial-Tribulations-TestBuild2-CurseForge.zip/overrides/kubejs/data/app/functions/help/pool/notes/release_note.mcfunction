tellraw @s[tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Pool and Billiards Datapack (YMS2001)"}]
tellraw @s[tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"<Detailed Readme Here>","underlined":true,"clickEvent":{"action":"open_url","value":"https://github.com/MingshiYangUIUC/Pool-Minecraft-Squid-Workshop-Project/blob/main/README.md"}}]

tellraw @s[tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"台球数据包(YMS2001)"}]
tellraw @s[tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"<详细使用说明>","underlined":true,"clickEvent":{"action":"open_url","value":"https://github.com/MingshiYangUIUC/Pool-Minecraft-Squid-Workshop-Project/blob/main/%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E.md"}}]

tellraw @s[tag=swPool_EN] [{"text":"➇ If you enjoy the datapack, feel free to leave a ⭐ or ❤. Thanks for playing!","color":"white"}]
tellraw @s[tag=swPool_CN] [{"text":"➇ 如果你喜欢这个数据包，欢迎随手点个 ⭐ 或 ❤。感谢游玩！","color":"white"}]

tellraw @s [{"text":"➇ ⭐ ","color":"aqua"},{"text":"<GitHub>","underlined":true,"clickEvent":{"action":"open_url","value":"https://github.com/MingshiYangUIUC/Pool-Minecraft-Squid-Workshop-Project"}}]
tellraw @s [{"text":"➇ ❤ ","color":"green"},{"text":"<Modrinth>","underlined":true,"clickEvent":{"action":"open_url","value":"https://modrinth.com/datapack/pool-and-billiards"}}]
tellraw @s [{"text":"➇ ❤ ","color":"gold"},{"text":"<CurseForge>","underlined":true,"clickEvent":{"action":"open_url","value":"https://www.curseforge.com/minecraft/data-packs/pool-and-billiards"}}]
