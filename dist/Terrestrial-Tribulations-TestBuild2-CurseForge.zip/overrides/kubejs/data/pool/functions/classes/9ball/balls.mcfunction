###########################   +
#P                       P#
#                         #
#                         #
#                         #	3 reds: 23750
#                         #	n reds: 43750
#                         #
#                         #
#                         #
#                         #v
#                         #a
#P                       P#r
#                         #0
#                         #0
#                         #
#                         #
#                         #
#            D            #
#           D D           #
#          DDDDD          #
#                         #
#                         #
#P                       P#
###########################
#          var01

tag @s remove swPool_snookermode
tag @s remove swPool_practicemode
tag @s add swPool_9ballmode
scoreboard players set swPool_9ballmode swMath_V 1
tag @s remove swPool_x
tag @s remove swPool_z

execute if score @s swPool_sizex >= @s swPool_sizez run scoreboard players operation @s swPool_dl = TABLE swPool_sizex
execute if score @s swPool_sizex >= @s swPool_sizez run scoreboard players operation @s swPool_ds = TABLE swPool_sizez
execute if score @s swPool_sizex < @s swPool_sizez run scoreboard players operation @s swPool_dl = TABLE swPool_sizez
execute if score @s swPool_sizex < @s swPool_sizez run scoreboard players operation @s swPool_ds = TABLE swPool_sizex
scoreboard players operation TABLE swPool_dl = @s swPool_dl
scoreboard players operation TABLE swPool_ds = @s swPool_ds

execute if score @s swPool_sizex >= @s swPool_sizez run tag @s add swPool_x
execute if score @s swPool_sizex < @s swPool_sizez run tag @s add swPool_z


scoreboard players set old_r swMath_V 1250

# scale the shift by r and table size
scoreboard players set #dlshift swMath_V 4330
scoreboard players operation #dlshift swMath_V *= C_r swPool_C
scoreboard players operation #dlshift swMath_V /= old_r swMath_V
scoreboard players operation #dlshift swMath_V += C_r swPool_C

# Ball 09
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_09","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V

execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_09,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_09,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_09,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_09,limit=1] swPool_var01 = @s swPool_var00

########BEGIN Red D
##1
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_01","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add 2500
scoreboard players set @s swPool_var02 -4500
scoreboard players operation @s swPool_var02 *= C_r swPool_C
scoreboard players operation @s swPool_var02 /= old_r swMath_V
scoreboard players set @s swPool_var03 0

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_01,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_01,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_01,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_01,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_01,limit=1] remove swPool_new

##2
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_solid","swPool_rand","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add 2500
scoreboard players set @s swPool_var02 -2250
scoreboard players operation @s swPool_var02 *= C_r swPool_C
scoreboard players operation @s swPool_var02 /= old_r swMath_V
scoreboard players set @s swPool_var03 -1300
scoreboard players operation @s swPool_var03 *= C_r swPool_C
scoreboard players operation @s swPool_var03 /= old_r swMath_V

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_rand,tag=swPool_new,limit=1] remove swPool_new

##3
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_solid","swPool_rand","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add/remove 2166/1250/2500
scoreboard players set @s swPool_var02 -2250
scoreboard players operation @s swPool_var02 *= C_r swPool_C
scoreboard players operation @s swPool_var02 /= old_r swMath_V
scoreboard players set @s swPool_var03 1300
scoreboard players operation @s swPool_var03 *= C_r swPool_C
scoreboard players operation @s swPool_var03 /= old_r swMath_V

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_rand,tag=swPool_new,limit=1] remove swPool_new

##4
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_solid","swPool_rand","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add/remove 2166/1250/2500
scoreboard players set @s swPool_var02 2250
scoreboard players operation @s swPool_var02 *= C_r swPool_C
scoreboard players operation @s swPool_var02 /= old_r swMath_V
scoreboard players set @s swPool_var03 1300
scoreboard players operation @s swPool_var03 *= C_r swPool_C
scoreboard players operation @s swPool_var03 /= old_r swMath_V

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_rand,tag=swPool_new,limit=1] remove swPool_new

##5
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_solid","swPool_rand","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add/remove 2166/1250/2500
scoreboard players set @s swPool_var02 2250
scoreboard players operation @s swPool_var02 *= C_r swPool_C
scoreboard players operation @s swPool_var02 /= old_r swMath_V
scoreboard players set @s swPool_var03 -1300
scoreboard players operation @s swPool_var03 *= C_r swPool_C
scoreboard players operation @s swPool_var03 /= old_r swMath_V

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_rand,tag=swPool_new,limit=1] remove swPool_new

##6
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_solid","swPool_rand","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add/remove 2166/1250/2500
scoreboard players set @s swPool_var02 4500
scoreboard players operation @s swPool_var02 *= C_r swPool_C
scoreboard players operation @s swPool_var02 /= old_r swMath_V
scoreboard players set @s swPool_var03 0

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_rand,tag=swPool_new,limit=1] remove swPool_new

##7
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_solid","swPool_rand","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add/remove 2166/1250/2500
scoreboard players set @s swPool_var02 0
scoreboard players set @s swPool_var03 -2600
scoreboard players operation @s swPool_var03 *= C_r swPool_C
scoreboard players operation @s swPool_var03 /= old_r swMath_V

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_rand,tag=swPool_new,limit=1] remove swPool_new

##14
execute store result score @s[tag=swPool_x] swPool_var00 run data get entity @s Pos[0] 10000
execute store result score @s[tag=swPool_x] swPool_var01 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var00 run data get entity @s Pos[2] 10000
execute store result score @s[tag=swPool_z] swPool_var01 run data get entity @s Pos[0] 10000
summon armor_stand ~ ~ ~ {Marker:1b,Tags:["swPool_pool","swPool_solid","swPool_rand","swPool_new","swPool_bk"],NoGravity:1,Small:1,Invisible:1}
scoreboard players set @s swPool_var05 2
scoreboard players operation @s swPool_var02 = @s swPool_dl
scoreboard players operation @s swPool_var02 /= @s swPool_var05
scoreboard players set @s swPool_var03 0
scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03

#change individuals by changing swPool_var02 and swPool_var03 add/remove 2166/1250/2500
scoreboard players set @s swPool_var02 0
scoreboard players set @s swPool_var03 2600
scoreboard players operation @s swPool_var03 *= C_r swPool_C
scoreboard players operation @s swPool_var03 /= old_r swMath_V

scoreboard players operation @s swPool_var00 -= @s swPool_var02
scoreboard players operation @s swPool_var01 += @s swPool_var03
scoreboard players operation @s swPool_var00 -= #dlshift swMath_V
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var00
execute if entity @s[tag=swPool_x] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var00 = @s swPool_var01
execute if entity @s[tag=swPool_z] run scoreboard players operation @e[tag=swPool_rand,tag=swPool_new,limit=1] swPool_var01 = @s swPool_var00
tag @e[tag=swPool_rand,tag=swPool_new,limit=1] remove swPool_new



########END of RANDOM


#clear

tag @s remove swPool_moved
scoreboard players set @s swPool_lifetime 0
execute as @a store result score @s swPool_player run data get entity @s UUID[1]