# respot, undo, ball in hand

# respot if clear scratch, otherwise do nothing
#execute unless entity @e[type=armor_stand,tag=swPool_pool,tag=swPool_09,limit=1] unless entity @e[type=armor_stand,tag=swPool_pool,tag=swPool_cue,limit=1] run function pool:classes/master/9ball/respot_9

execute unless entity @e[type=armor_stand,tag=swPool_pool,tag=swPool_09,limit=1] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"<Respot?>","color":"white","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 41112177"}}]
execute unless entity @e[type=armor_stand,tag=swPool_pool,tag=swPool_09,limit=1] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"<复位九号球？>","color":"white","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 41112177"}}]

tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":""},{"underlined":true,"text":"<Command Window>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 1"}},{"text":" ","underlined":false},{"underlined":true,"text":"<undo>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4111212"}},{"text":" ","underlined":false},{"underlined":true,"text":"<Ball in Hand>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 41112201"}}]
tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"<Adjust the next strike.>","color":"white","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4110806"}}]

tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":""},{"underlined":true,"text":"<命令窗口>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 1"}},{"text":" ","underlined":false},{"underlined":true,"text":"<撤销上次击球>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4111212"}},{"text":" ","underlined":false},{"underlined":true,"text":"<手中球>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 41112201"}}]
tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"<调整下一次击球>","color":"white","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4110806"}}]
