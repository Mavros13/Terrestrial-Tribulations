# end of bot turn
execute unless score #muteall swPool_C matches 1 if entity @e[tag=swPool_botmode] if entity @e[tag=swPool_bot_thinking] run function pool:classes/bot/generic/__kill_equip
execute unless score #muteall swPool_C matches 1 if entity @e[tag=swPool_botmode] if entity @e[tag=swPool_bot_thinking] run function pool:classes/bot/generic/__cleanup

# cancel all fastfwd anyway during regular turn
execute unless score #muteall swPool_C matches 1 run scoreboard players set #fastfwd swMath_V 0
execute unless score #muteall swPool_C matches 1 run scoreboard players set #fastfwd_tmp swMath_V 0
execute unless score #muteall swPool_C matches 1 run scoreboard players set #fastfwd_tmp_d1 swMath_V 0
execute unless score #muteall swPool_C matches 1 run scoreboard players set #fastfwd_maxiter swMath_V 1
execute unless score #muteall swPool_C matches 1 run scoreboard players set #fastfwd_bot swMath_V 0

# turn end indicator
execute unless score #muteall swPool_C matches 1 run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ --------","color":"white"}]
execute unless score #muteall swPool_C matches 1 run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ --------","color":"white"}]

# give new arrow if in survival mode
execute unless score #muteall swPool_C matches 1 as @a[tag=swPool_hitcue,tag=swPool_poolplay,gamemode=!creative] run function app:get/pool/arrow_helper

execute unless data storage minecraft:swpool automatic_judge_off if entity @s[tag=swPool_snookermode] run scoreboard players set @s[scores={swPool_foul=..3}] swPool_foul 4

# six replace calls to be safe
execute unless data storage minecraft:swpool automatic_judge_off if entity @s[tag=swPool_snookermode] as @s[tag=swPool_pocketing] run function pool:classes/pocketing/snooker/replace
execute unless data storage minecraft:swpool automatic_judge_off if entity @s[tag=swPool_snookermode] as @s[tag=swPool_pocketing] run function pool:classes/pocketing/snooker/replace
execute unless data storage minecraft:swpool automatic_judge_off if entity @s[tag=swPool_snookermode] as @s[tag=swPool_pocketing] run function pool:classes/pocketing/snooker/replace
execute unless data storage minecraft:swpool automatic_judge_off if entity @s[tag=swPool_snookermode] as @s[tag=swPool_pocketing] run function pool:classes/pocketing/snooker/replace
execute unless data storage minecraft:swpool automatic_judge_off if entity @s[tag=swPool_snookermode] as @s[tag=swPool_pocketing] run function pool:classes/pocketing/snooker/replace
execute unless data storage minecraft:swpool automatic_judge_off if entity @s[tag=swPool_snookermode] as @s[tag=swPool_pocketing] run function pool:classes/pocketing/snooker/replace

# bypass
#execute if entity @s[tag=swPool_snookermode] run scoreboard players set @s[scores={swPool_foul=..3}] swPool_foul 4
#execute if entity @s[tag=swPool_snookermode] as @s[tag=swPool_pocketing] run function pool:classes/pocketing/snooker/replace

tag @s[tag=swPool_uk8ballmode] remove swPool_pocketing
tag @s[tag=swPool_cn8ballmode] remove swPool_pocketing
tag @s[tag=swPool_9ballmode] remove swPool_pocketing
tag @s[tag=swPool_practicemode] remove swPool_pocketing
tag @s[tag=swPool_snookermode] remove swPool_pocketing

# use respective rules unless practice mode and auto judge off
execute unless data storage minecraft:swpool automatic_judge_off if entity @e[tag=swPool_hitcue] as @s[tag=swPool_9ballmode,tag=!swPool_pocketing] unless entity @s[tag=swPool_endgame] run function pool:classes/master/9ball/progression
execute unless data storage minecraft:swpool automatic_judge_off if entity @e[tag=swPool_hitcue] as @s[tag=swPool_cn8ballmode,tag=!swPool_pocketing] run function pool:classes/master/cn8ball/progression
execute unless data storage minecraft:swpool automatic_judge_off if entity @e[tag=swPool_hitcue] as @s[tag=swPool_snookermode,tag=!swPool_pocketing] run function pool:classes/master/snooker/progression
execute unless data storage minecraft:swpool automatic_judge_off if entity @a[tag=swPool_hitcue] as @s[tag=swPool_uk8ballmode,tag=!swPool_pocketing] run function pool:classes/master/uk8ball/progression

# if no rule, by pass replace and progression but use progression_norule
execute if data storage minecraft:swpool automatic_judge_off if entity @a[tag=swPool_hitcue] as @s[tag=swPool_9ballmode,tag=!swPool_pocketing] unless entity @s[tag=swPool_endgame] run function pool:classes/master/9ball/progression_norule
execute if data storage minecraft:swpool automatic_judge_off if entity @a[tag=swPool_hitcue] as @s[tag=swPool_cn8ballmode,tag=!swPool_pocketing] run function pool:classes/master/cn8ball/progression_norule
execute if data storage minecraft:swpool automatic_judge_off if entity @a[tag=swPool_hitcue] as @s[tag=swPool_snookermode,tag=!swPool_pocketing] run function pool:classes/master/snooker/progression_norule
execute if data storage minecraft:swpool automatic_judge_off if entity @a[tag=swPool_hitcue] as @s[tag=swPool_uk8ballmode,tag=!swPool_pocketing] run function pool:classes/master/uk8ball/progression_norule

execute if entity @a[tag=swPool_hitcue] as @s[tag=swPool_practicemode,tag=!swPool_pocketing] run function pool:classes/master/practice/progression

tag @e[tag=swPool_a1] remove swPool_a1

tag @e[tag=swPool_colliding] remove swPool_colliding

tag @s add swPool_progressed

scoreboard players reset @e[tag=swPool_fake] swPool_v

# reset out of table bug undo scheduler
execute unless score #muteall swPool_C matches 1 as @e[tag=swPool_pool,tag=swPool_placed] run function pool:classes/cushion/detect_out_of_table
scoreboard players set #outoftable_scheduled swPool_var00 0