tag 000c2be1-0001-414d-0000-000000000000 remove swPool_multiplayer
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_singleplayer

tellraw @a[tag=swPool_debug_snooker] [{"text":"nred, "},{"score":{"objective":"swPool_nred","name":"@s"}}]
tellraw @a[tag=swPool_debug_snooker] [{"text":"ncolor, "},{"score":{"objective":"swPool_ncolor","name":"@s"}}]

execute as @e[tag=swPool_poolplay,limit=1] at @s if entity @e[tag=swPool_poolplay,distance=0.1..] run tag 000c2be1-0001-414d-0000-000000000000 add swPool_multiplayer
execute as @e[tag=swPool_poolplay,limit=1] at @s unless entity @e[tag=swPool_poolplay,distance=0.1..] run tag 000c2be1-0001-414d-0000-000000000000 add swPool_singleplayer

execute unless entity @e[tag=swPool_hitcue,scores={swPool_firsthit=1..7}] run scoreboard players set @s[scores={swPool_foul=..3}] swPool_foul 4

execute unless entity @s[scores={swPool_var05=-10000000..10000000}] run scoreboard players set @s swPool_var05 0
scoreboard players operation @e[tag=swPool_red,tag=swPool_pool] swPool_rank = rank1 swPool_rank
scoreboard players operation @e[tag=swPool_yellow,tag=swPool_pool] swPool_rank = rank2 swPool_rank
scoreboard players operation @e[tag=swPool_green,tag=swPool_pool] swPool_rank = rank3 swPool_rank
scoreboard players operation @e[tag=swPool_brown,tag=swPool_pool] swPool_rank = rank4 swPool_rank
scoreboard players operation @e[tag=swPool_blue,tag=swPool_pool] swPool_rank = rank5 swPool_rank
scoreboard players operation @e[tag=swPool_pink,tag=swPool_pool] swPool_rank = rank6 swPool_rank
scoreboard players operation @e[tag=swPool_black,tag=swPool_pool] swPool_rank = rank7 swPool_rank


execute if entity @s[scores={swPool_firsthit=1..7}] unless score @e[tag=swPool_hitcue,limit=1] swPool_firsthit = @s swPool_firsthit run tag @s add swPool_fouled1
execute if entity @s[scores={swPool_firsthit=8}] unless entity @e[tag=swPool_hitcue,scores={swPool_firsthit=2..7}] run tag @s add swPool_fouled1
execute if data storage minecraft:swpool feedback_foul if entity @s[tag=swPool_fouled1] run tellraw @a[tag=swPool_hitcue,limit=1,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"犯规原因：未击中正确的球。"}]
execute if data storage minecraft:swpool feedback_foul if entity @s[tag=swPool_fouled1] run tellraw @a[tag=swPool_hitcue,limit=1,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Reason of foul: did not hit the correct balls."}]
tag @s[tag=swPool_fouled1] add swPool_fouled
tag @s[tag=swPool_fouled1] remove swPool_fouled1
#execute if entity @s[tag=swPool_fouled] run say fouled

scoreboard players set @s[tag=!swPool_fouled] swPool_foul 0

execute if entity @e[tag=swPool_red,tag=swPool_pool] run scoreboard players set @s[tag=swPool_fouled] swPool_firsthit 1
execute unless entity @e[tag=swPool_pool,scores={swPool_rank=1}] if entity @e[tag=swPool_pool,scores={swPool_rank=2}] run scoreboard players set @s swPool_firsthit 2
execute unless entity @e[tag=swPool_pool,scores={swPool_rank=1..2}] if entity @e[tag=swPool_pool,scores={swPool_rank=3}] run scoreboard players set @s swPool_firsthit 3
execute unless entity @e[tag=swPool_pool,scores={swPool_rank=1..3}] if entity @e[tag=swPool_pool,scores={swPool_rank=4}] run scoreboard players set @s swPool_firsthit 4
execute unless entity @e[tag=swPool_pool,scores={swPool_rank=1..4}] if entity @e[tag=swPool_pool,scores={swPool_rank=5}] run scoreboard players set @s swPool_firsthit 5
execute unless entity @e[tag=swPool_pool,scores={swPool_rank=1..5}] if entity @e[tag=swPool_pool,scores={swPool_rank=6}] run scoreboard players set @s swPool_firsthit 6
execute unless entity @e[tag=swPool_pool,scores={swPool_rank=1..6}] if entity @e[tag=swPool_pool,scores={swPool_rank=7}] run scoreboard players set @s swPool_firsthit 7
execute unless entity @e[tag=swPool_pool,scores={swPool_rank=1..7}] run scoreboard players set @s swPool_firsthit -1

execute if entity @s[tag=swPool_firstcolor] unless entity @s[tag=swPool_fouled] run scoreboard players set @s[scores={swPool_firsthit=8}] swPool_firsthit 2

execute unless entity @e[tag=swPool_red,tag=swPool_pool] run scoreboard players set @s[tag=!swPool_fouled,tag=swPool_lastred,scores={swPool_firsthit=1..2}] swPool_firsthit 8
execute if entity @e[tag=swPool_red,tag=swPool_pool] run scoreboard players set @s[tag=!swPool_fouled,scores={swPool_firsthit=8}] swPool_firsthit 1
execute if entity @e[tag=swPool_red,tag=swPool_pool] if entity @s[scores={swPool_nred=1..}] run scoreboard players set @s[tag=!swPool_fouled,scores={swPool_firsthit=1}] swPool_firsthit 8

execute as @s[tag=swPool_fouled] unless entity @s[scores={swPool_foul=5..7}] run scoreboard players set @s swPool_foul 4

#score changes
scoreboard players operation @s[tag=swPool_fouled] swPool_foul > @e[tag=swPool_hitcue,limit=1] swPool_firsthit
scoreboard players set @s[tag=swPool_fouled] swPool_var05 0

scoreboard players operation @e[tag=swPool_hitcue,limit=1] swPool_Score += @s swPool_var05
scoreboard players operation @e[tag=swPool_poolplay,tag=!swPool_hitcue] swPool_Score += @s[tag=swPool_fouled] swPool_foul
execute if entity @s[tag=swPool_singleplayer] run scoreboard players operation Opponent swPool_Score += @s[tag=swPool_fouled] swPool_foul



#score messages:
execute if entity @s[tag=swPool_singleplayer,tag=swPool_dialogue] as @e[tag=swPool_poolplay,limit=1] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"selector":"@s"},{"text":": "},{"score":{"objective":"swPool_Score","name":"@s"}},{"text":" | Opponent: "},{"score":{"objective":"swPool_Score","name":"Opponent"}}]
execute if entity @s[tag=swPool_singleplayer,tag=swPool_dialogue] as @e[tag=swPool_poolplay,limit=1] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"selector":"@s"},{"text":": "},{"score":{"objective":"swPool_Score","name":"@s"}},{"text":" | 对手: "},{"score":{"objective":"swPool_Score","name":"Opponent"}}]
execute if entity @s[tag=swPool_multiplayer,tag=swPool_dialogue] as @e[tag=swPool_poolplay,limit=1] at @s run tellraw @a[tag=swPool_spec] [{"text":"➇ ","color":"white"},{"selector":"@s"},{"text":": "},{"score":{"objective":"swPool_Score","name":"@s"}},{"text":" | "},{"selector":"@e[distance=0.01..,tag=swPool_poolplay,limit=1,sort=nearest]"},{"text":": "},{"score":{"objective":"swPool_Score","name":"@e[distance=0.01..,tag=swPool_poolplay,limit=1,sort=nearest]"}}]

#english messages...
execute if entity @s[tag=swPool_fouled,tag=swPool_singleplayer] unless entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Foul. Opponent "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":"."}]
execute if entity @s[tag=swPool_fouled,tag=swPool_singleplayer] if entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Foul. Opponent "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":", ball in hand in D-Zone."}]

execute if entity @s[tag=swPool_fouled,tag=swPool_multiplayer] unless entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Foul. "},{"selector":"@e[tag=!swPool_hitcue,tag=swPool_poolplay]"},{"text":" "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":"."}]
execute if entity @s[tag=swPool_fouled,tag=swPool_multiplayer] if entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Foul. "},{"selector":"@e[tag=!swPool_hitcue,tag=swPool_poolplay]"},{"text":" "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":", gets ball in hand in D-Zone."}]

execute if entity @s[scores={swPool_firsthit=1}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Red."}]
execute if entity @s[scores={swPool_firsthit=2}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Yellow."}]
execute if entity @s[scores={swPool_firsthit=3}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Green."}]
execute if entity @s[scores={swPool_firsthit=4}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Brown."}]
execute if entity @s[scores={swPool_firsthit=5}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Blue."}]
execute if entity @s[scores={swPool_firsthit=6}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Pink."}]
execute if entity @s[scores={swPool_firsthit=7}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Black."}]
execute if entity @s[scores={swPool_firsthit=8}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":", Target ball is Colour."}]


#chinese messages...
execute if entity @s[tag=swPool_fouled,tag=swPool_singleplayer] unless entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"犯规。对手得 "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":" 分。"}]
execute if entity @s[tag=swPool_fouled,tag=swPool_singleplayer] if entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"犯规。对手得 "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":" 分，请在D-区放置母球。"}]

execute if entity @s[tag=swPool_fouled,tag=swPool_multiplayer] unless entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"犯规。"},{"selector":"@e[tag=!swPool_hitcue,tag=swPool_poolplay]"},{"text":"得 "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":" 分。"}]
execute if entity @s[tag=swPool_fouled,tag=swPool_multiplayer] if entity @e[tag=swPool_poolplay,tag=swPool_ballinhand] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"犯规。"},{"selector":"@e[tag=!swPool_hitcue,tag=swPool_poolplay]"},{"text":"得 "},{"score":{"objective":"swPool_foul","name":"@s"}},{"text":" 分，请在D-区放置母球。"}]

execute if entity @s[scores={swPool_firsthit=1}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为红球。"}]
execute if entity @s[scores={swPool_firsthit=2}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为黄球。"}]
execute if entity @s[scores={swPool_firsthit=3}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为绿球。"}]
execute if entity @s[scores={swPool_firsthit=4}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为咖啡球。"}]
execute if entity @s[scores={swPool_firsthit=5}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为蓝球。"}]
execute if entity @s[scores={swPool_firsthit=6}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为粉球。"}]
execute if entity @s[scores={swPool_firsthit=7}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为黑球。"}]
execute if entity @s[scores={swPool_firsthit=8}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"score":{"objective":"swPool_var05","name":"@s"}},{"text":" 分，目标球为任一彩球。"}]


#commands
execute if entity @s[scores={swPool_firsthit=-1}] run function pool:classes/master/snooker/endgame
execute if entity @s[scores={swPool_firsthit=2}] as @e[scores={swPool_rank=2}] run data merge entity @s {CustomNameVisible:1b}
execute if entity @s[scores={swPool_firsthit=3}] as @e[scores={swPool_rank=3}] run data merge entity @s {CustomNameVisible:1b}
execute if entity @s[scores={swPool_firsthit=4}] as @e[scores={swPool_rank=4}] run data merge entity @s {CustomNameVisible:1b}
execute if entity @s[scores={swPool_firsthit=5}] as @e[scores={swPool_rank=5}] run data merge entity @s {CustomNameVisible:1b}
execute if entity @s[scores={swPool_firsthit=6}] as @e[scores={swPool_rank=6}] run data merge entity @s {CustomNameVisible:1b}
execute if entity @s[scores={swPool_firsthit=7}] as @e[scores={swPool_rank=7}] run data merge entity @s {CustomNameVisible:1b}
execute if entity @s[scores={swPool_firsthit=8}] as @e[scores={swPool_rank=2..7}] run data merge entity @s {CustomNameVisible:1b}

schedule function pool:classes/master/snooker/hidename 3s


#more EN messages...
execute if entity @s[tag=swPool_singleplayer] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=swPool_hitcue]"},{"text":"'s Turn."}]

execute if entity @s[tag=swPool_multiplayer] if entity @s[tag=swPool_fouled] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=!swPool_hitcue]"},{"text":"'s Turn."}]
execute if entity @s[tag=swPool_multiplayer] unless entity @s[tag=swPool_fouled] if entity @s[scores={swPool_var05=0}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=!swPool_hitcue]"},{"text":"'s Turn."}]
execute if entity @s[tag=swPool_multiplayer] unless entity @s[tag=swPool_fouled] if entity @s[scores={swPool_var05=1..}] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=swPool_hitcue]"},{"text":"'s Turn."}]

#more CN messages...
execute if entity @s[tag=swPool_singleplayer] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=swPool_hitcue]"},{"text":"请击球。"}]

execute if entity @s[tag=swPool_multiplayer] if entity @s[tag=swPool_fouled] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=!swPool_hitcue]"},{"text":"请击球。"}]
execute if entity @s[tag=swPool_multiplayer] unless entity @s[tag=swPool_fouled] if entity @s[scores={swPool_var05=0}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=!swPool_hitcue]"},{"text":"请击球。"}]
execute if entity @s[tag=swPool_multiplayer] unless entity @s[tag=swPool_fouled] if entity @s[scores={swPool_var05=1..}] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=swPool_hitcue]"},{"text":"请击球。"}]

# determine next player
tag @e[tag=swPool_poolplay] remove swPool_nextturn
scoreboard players set #switchplayer swPool_var00 0

# foul or legal miss switches player
execute if entity @s[tag=swPool_fouled] run scoreboard players set #switchplayer swPool_var00 1
execute unless entity @s[tag=swPool_fouled] if score @s swPool_var05 matches 0 run scoreboard players set #switchplayer swPool_var00 1

# legal score keeps player
execute if entity @s[tag=swPool_multiplayer,tag=!swPool_endgame] if score #switchplayer swPool_var00 matches 0 run tag @e[tag=swPool_poolplay,tag=swPool_hitcue,limit=1] add swPool_nextturn
execute if entity @s[tag=swPool_multiplayer,tag=!swPool_endgame] if score #switchplayer swPool_var00 matches 1 run tag @e[tag=swPool_poolplay,tag=!swPool_hitcue,limit=1] add swPool_nextturn

# schedule bot if it is next
scoreboard players set #botmove swMath_V 0
execute unless entity @s[tag=swPool_endgame] if entity @e[tag=swPool_poolplay,tag=swPool_nextturn,tag=swPool_botmode] run scoreboard players set #botmove swMath_V 1
execute if score #botmove swMath_V matches 1 run schedule function pool:classes/bot/generic/__run_ai_helper 5t

# stop bot when frame ends
execute if entity @s[tag=swPool_endgame] run kill @e[tag=swPool_botmode]

# NEW check free ball if fouled before
tag @s remove swPool_freeball_turn
# no free ball given for ball in hand because it is just unlikely to get totally stuck.
execute if entity @s[tag=swPool_fouled] if entity @e[tag=swPool_cue,tag=swPool_pool] run function pool:classes/master/snooker/freeball_main
# give swPool_freeball_turn to pooltable if freeball, and next turn it will adjust
# record actual ball on for this free-ball turn
scoreboard players set #freeball_target swMath_V 0
execute if entity @s[tag=swPool_freeball_turn] run scoreboard players operation #freeball_target swMath_V = @s swPool_firsthit

execute if entity @s[tag=swPool_singleplayer] if entity @s[tag=swPool_freeball_turn] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=swPool_hitcue]"},{"text":" is awarded free ball."}]
execute if entity @s[tag=swPool_singleplayer] if entity @s[tag=swPool_freeball_turn] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=swPool_hitcue]"},{"text":"获得自由球。"}]

execute if entity @s[tag=swPool_multiplayer] if entity @s[tag=swPool_freeball_turn] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=!swPool_hitcue]"},{"text":" is awarded free ball."}]
execute if entity @s[tag=swPool_multiplayer] if entity @s[tag=swPool_freeball_turn] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"selector":"@e[tag=swPool_poolplay,tag=!swPool_hitcue]"},{"text":"获得自由球。"}]


#scoreboard players reset @e[tag=swPool_pool,tag=!swPool_red] swPool_rank
scoreboard players reset @e[tag=swPool_pool] swPool_player
tag @e remove swPool_hitcue
scoreboard players reset @e[tag=swPool_poolplay] swPool_firsthit
tag @e[tag=swPool_poolplay] remove swPool_nextturn
scoreboard players set @s[tag=swPool_fouled] swPool_foul 0
tag @s remove swPool_fouled
tag @s remove swPool_lastred
tag @s remove swPool_firstcolor
scoreboard players set @s swPool_nred 0
scoreboard players set @s swPool_ncolor 0
scoreboard players reset @s swPool_var05
scoreboard players add Stroke swPool_hidScore 1
tag @s remove swPool_freeball_potted
scoreboard players set #freeball_nom swMath_V 0

tag @a[tag=swPool_spectemp] add swPool_spec
tag @a[tag=swPool_spectemp] remove swPool_spectemp
#end messages

execute unless entity @e[type=armor_stand,tag=swPool_pooltable,tag=swPool_endgame] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":""},{"underlined":true,"text":"<Command Window>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 1"}},{"text":" ","underlined":false},{"underlined":true,"text":"<undo>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4111212"}}]
execute unless score #botmove swMath_V matches 1 unless entity @e[type=armor_stand,tag=swPool_pooltable,tag=swPool_endgame] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"<Adjust the next strike.>","color":"white","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4110806"}}]

execute unless entity @e[type=armor_stand,tag=swPool_pooltable,tag=swPool_endgame] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":""},{"underlined":true,"text":"<命令窗口>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 1"}},{"text":" ","underlined":false},{"underlined":true,"text":"<撤销上次击球>","color":"white","clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4111212"}}]
execute unless score #botmove swMath_V matches 1 unless entity @e[type=armor_stand,tag=swPool_pooltable,tag=swPool_endgame] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"<调整下一次击球>","color":"white","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger swPool__trigger set 4110806"}}]
