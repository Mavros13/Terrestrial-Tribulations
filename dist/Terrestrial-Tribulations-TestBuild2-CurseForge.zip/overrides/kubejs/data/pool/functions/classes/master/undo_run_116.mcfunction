#scoreboard players remove RedoTime swPool_hidScore 1



kill @e[tag=swPool_pool]

tag @e[tag=swPool_temppin] add swPool_pool


execute unless score #muteall swPool_C matches 1 run execute if data storage minecraft:swpool cueballreddot run replaceitem entity @e[tag=swPool_cue,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:1}
execute unless score #muteall swPool_C matches 1 run execute unless data storage minecraft:swpool cueballreddot run replaceitem entity @e[tag=swPool_cue,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:36}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_red,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:2}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_yellow,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:3}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_green,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:4}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_brown,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:5}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_blue,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:6}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_pink,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:7}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_black,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:8}

execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_01,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:21}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_02,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:22}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_03,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:23}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_04,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:24}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_05,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:25}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_06,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:26}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_07,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:27}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_08,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:28}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_09,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:29}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_10,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:30}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_11,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:31}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_12,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:32}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_13,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:33}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_14,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:34}
execute unless score #muteall swPool_C matches 1 run replaceitem entity @e[tag=swPool_15,tag=swPool_temppin] armor.head minecraft:acacia_button{CustomModelData:35}

execute if score swPool_snookermode swMath_V matches 1 run scoreboard players operation @e[tag=swPool_red,tag=swPool_temppin] swPool_rank = rank1 swPool_rank
execute if score swPool_snookermode swMath_V matches 1 run scoreboard players operation @e[tag=swPool_yellow,tag=swPool_temppin] swPool_rank = rank2 swPool_rank
execute if score swPool_snookermode swMath_V matches 1 run scoreboard players operation @e[tag=swPool_green,tag=swPool_temppin] swPool_rank = rank3 swPool_rank
execute if score swPool_snookermode swMath_V matches 1 run scoreboard players operation @e[tag=swPool_brown,tag=swPool_temppin] swPool_rank = rank4 swPool_rank
execute if score swPool_snookermode swMath_V matches 1 run scoreboard players operation @e[tag=swPool_blue,tag=swPool_temppin] swPool_rank = rank5 swPool_rank
execute if score swPool_snookermode swMath_V matches 1 run scoreboard players operation @e[tag=swPool_pink,tag=swPool_temppin] swPool_rank = rank6 swPool_rank
execute if score swPool_snookermode swMath_V matches 1 run scoreboard players operation @e[tag=swPool_black,tag=swPool_temppin] swPool_rank = rank7 swPool_rank

execute if score swPool_snookermode swMath_V matches 1 run execute as @e[scores={swPool_rank=2}] run data merge entity @s {CustomName:"\"2 Pts\""}
execute if score swPool_snookermode swMath_V matches 1 run execute as @e[scores={swPool_rank=3}] run data merge entity @s {CustomName:"\"3 Pts\""}
execute if score swPool_snookermode swMath_V matches 1 run execute as @e[scores={swPool_rank=4}] run data merge entity @s {CustomName:"\"4 Pts\""}
execute if score swPool_snookermode swMath_V matches 1 run execute as @e[scores={swPool_rank=5}] run data merge entity @s {CustomName:"\"5 Pts\""}
execute if score swPool_snookermode swMath_V matches 1 run execute as @e[scores={swPool_rank=6}] run data merge entity @s {CustomName:"\"6 Pts\""}
execute if score swPool_snookermode swMath_V matches 1 run execute as @e[scores={swPool_rank=7}] run data merge entity @s {CustomName:"\"7 Pts\""}

scoreboard players set @e[tag=swPool_pool] swPool_D100 100000
scoreboard players set @e[tag=swPool_pool] swPool_DXX 99000

tag @e[tag=swPool_temppin] remove swPool_temppin


execute as @e[tag=swPool_poolplay] run scoreboard players operation @s swPool_Score = @s swPool_hidScore

scoreboard players operation Opponent swPool_Score = Opponent swPool_hidScore

scoreboard players operation Stroke swPool_hidScore = StrokeRec swPool_hidScore

scoreboard players operation 000c2be1-0001-414d-0000-000000000000 swPool_firsthit = FirstHit swPool_hidScore

scoreboard players operation #freeball_target swMath_V = #freeball_target swPool_hidScore

scoreboard players operation #breakshot swPool_v = #breakshot swPool_hidScore
execute if score #breakshot swPool_v matches 1 run tag @e[tag=swPool_pooltable,tag=swPool_uk8ballmode] add swPool_8ball_aibreak
execute if score #breakshot swPool_v matches 1 run tag @e[tag=swPool_pooltable,tag=swPool_cn8ballmode] add swPool_8ball_aibreak
execute if score #breakshot swPool_v matches 1 run tag @e[tag=swPool_pooltable,tag=swPool_9ballmode] add swPool_9ball_aibreak
execute if score #breakshot swPool_v matches 1 if entity @e[tag=swPool_pooltable,tag=swPool_uk8ballmode] run scoreboard players set swPool_8ball_aibreak swMath_V 1
execute if score #breakshot swPool_v matches 1 if entity @e[tag=swPool_pooltable,tag=swPool_cn8ballmode] run scoreboard players set swPool_8ball_aibreak swMath_V 1
execute if score #breakshot swPool_v matches 1 if entity @e[tag=swPool_pooltable,tag=swPool_9ballmode] run scoreboard players set swPool_8ball_aibreak swMath_V 1

scoreboard players operation Pocketed_Total swPool_hidScore = Pocketed_T_rec swPool_hidScore
scoreboard players operation Pocketed_Turn swPool_hidScore = Pocketed_Turn_rec swPool_hidScore

tag @a remove swPool_ballinhand
tag @a remove swPool_aimred
tag @a remove swPool_aimylw
tag @a remove swPool_aimblk
tag @a remove swPool_aimsolid
tag @a remove swPool_aimstripe
tag @a remove swPool_aim08
tag @a remove swPool_streak
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_awarded
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_endaward

tag @a[tag=swPool_redrec] add swPool_aimred
tag @a[tag=swPool_ylwrec] add swPool_aimylw
tag @a[tag=swPool_blkrec] add swPool_aimblk
tag @a[tag=swPool_solidrec] add swPool_aimsolid
tag @a[tag=swPool_striperec] add swPool_aimstripe
tag @a[tag=swPool_08rec] add swPool_aim08
tag @a[tag=swPool_stkrec] add swPool_streak

tag @e[tag=swPool_awdrec] add swPool_awarded
tag @e[tag=swPool_edawdrec] add swPool_endaward

tag @a remove swPool_redrec
tag @a remove swPool_ylwrec
tag @a remove swPool_blkrec
tag @a remove swPool_solidrec
tag @a remove swPool_striperec
tag @a remove swPool_08rec
tag @a remove swPool_stkrec
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_awdrec
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_edawdrec

tag 000c2be1-0001-414d-0000-000000000000 remove swPool_cn8ball_breaking
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_cn8ball_open
execute as 000c2be1-0001-414d-0000-000000000000 run tag @s[tag=swPool_cn8ball_breakingrec] add swPool_cn8ball_breaking
execute as 000c2be1-0001-414d-0000-000000000000 run tag @s[tag=swPool_cn8ball_openrec] add swPool_cn8ball_open
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_cn8ball_breakingrec
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_cn8ball_openrec

tag @e[tag=swPool_pooltable,tag=swPool_freeball_turnrec] add swPool_freeball_turn
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_freeball_turnrec

scoreboard players set 000c2be1-0001-414d-0000-000000000000 swPool_nred 0
scoreboard players set 000c2be1-0001-414d-0000-000000000000 swPool_ncolor 0
#score counter var05
scoreboard players set 000c2be1-0001-414d-0000-000000000000 swPool_var05 0
tag @a[tag=swPool_poolplay] remove swPool_fouled
scoreboard players set @a[tag=swPool_poolplay] swPool_foul 0
scoreboard players reset @a[tag=swPool_hitcue] swPool_firsthit
tag @a[tag=swPool_hitcue] remove swPool_hitcue

execute unless score #muteall swPool_C matches 1 run execute if entity @e[tag=!swPool_practicemode,tag=swPool_pooltable] run tellraw @a[tag=swPool_spec,tag=swPool_EN] [{"text":"➇ ","color":"white"},{"text":"Done. Backed to the previous turn. The last player, please try again."}]

execute unless score #muteall swPool_C matches 1 run execute if entity @e[tag=!swPool_practicemode,tag=swPool_pooltable] run tellraw @a[tag=swPool_spec,tag=swPool_CN] [{"text":"➇ ","color":"white"},{"text":"完成回到上一回合。上回合击球方请重新摆/击球。"}]

function pool:classes/master/record


tag @a[tag=swPool_placingcue] add swPool_ballinhand
tag @a[tag=swPool_placingcue] remove swPool_placingcue

execute if entity @e[tag=swPool_cue,tag=swPool_pool] run tag @a remove swPool_ballinhand
execute if entity @e[tag=swPool_cue,tag=swPool_pool] if entity @e[tag=!swPool_practicemode,tag=swPool_pooltable] run clear @a carrot_on_a_stick{CustomModelData:99}
execute if entity @e[tag=swPool_cue,tag=swPool_pool] if entity @e[tag=!swPool_practicemode,tag=swPool_pooltable] run clear @a carrot_on_a_stick{CustomModelData:100}

tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pktblk
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pkt08
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_rerack
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_endgame

tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pktcue
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pktsolid
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pktstripe
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pkt08
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pktred
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pktylw
tag 000c2be1-0001-414d-0000-000000000000 remove swPool_pktblk
